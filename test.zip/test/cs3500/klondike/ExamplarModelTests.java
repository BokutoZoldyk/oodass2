package cs3500.klondike;

import cs3500.klondike.model.hw02.KlondikeModel;
import cs3500.klondike.model.hw02.BasicKlondike;
import cs3500.klondike.model.hw02.Card;

import org.junit.Assert;
import org.junit.Test;

public class ExamplarModelTests {

  @Test
  public void testSomething() {
    // use the various Assert static methods to build your examples here.
  }
}
