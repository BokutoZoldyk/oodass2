package cs3500.klondike.model.hw02;


public interface Card {


  String toString();

  int getValue();

  Suit getSuit();
}
