package cs3500.klondike.model.hw02;

public class FaceDownCard implements Card {

  private static final String FACE_DOWN_CARD_STRING = "[Face Down Card]";

  @Override
  public String toString() {
    return FACE_DOWN_CARD_STRING;
  }

  @Override
  public int getValue() {
    return 0; // Face down card has no value
  }

  @Override
  public Suit getSuit() {
    return null; // Face down card has no suit
  }


  @Override
  public boolean equals(Object other) {
    return other instanceof FaceDownCard;
  }

  @Override
  public int hashCode() {
    return FACE_DOWN_CARD_STRING.hashCode();
  }
}
