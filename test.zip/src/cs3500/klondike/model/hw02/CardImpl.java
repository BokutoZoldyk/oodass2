package cs3500.klondike.model.hw02;

import java.util.Objects;

public class CardImpl implements Card {
    enum Suit {
        CLUBS('♣'), SPADES('♠'), HEARTS('♡'), DIAMONDS('♢');

        private final char symbol;

        Suit(char symbol) {
            this.symbol = symbol;
        }

        char getSymbol() {
            return symbol;
        }
    }

    private final int value;
    private final Suit suit;

    public CardImpl(int value, Suit suit) {
        if (value < 1 || value > 13) {
            throw new IllegalArgumentException("Invalid card value");
        }
        this.value = value;
        this.suit = suit;
    }

    @Override
    public String toString() {
        String valueStr;
        switch (value) {
            case 1:
                valueStr = "A";
                break;
            case 11:
                valueStr = "J";
                break;
            case 12:
                valueStr = "Q";
                break;
            case 13:
                valueStr = "K";
                break;
            default:
                valueStr = String.valueOf(value);
        }
        return valueStr + suit.getSymbol();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CardImpl card = (CardImpl) o;
        return value == card.value && suit == card.suit;
    }

    @Override
    public int hashCode() {
        return Objects.hash(value, suit);
    }
}
