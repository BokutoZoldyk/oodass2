package cs3500.klondike.model.hw02;

import java.util.ArrayList;
import java.util.List;
import java.util.Collections;


public class BasicKlondike implements KlondikeModel {

  private List<Card> deck;
  private List<List<Card>> tableauPiles;
  private List<Card> drawPile;
  private List<List<Card>> foundationPiles;
  private boolean gameStarted;

  public BasicKlondike() {
    deck = new ArrayList<>();
    tableauPiles = new ArrayList<>();
    drawPile = new ArrayList<>();
    foundationPiles = new ArrayList<>();
  }

  public void startGame(List<Card> deck, int numPiles, int numDraw) {

    // Shuffle deck
    Collections.shuffle(deck);

    // Initialize tableau piles
    tableauPiles = new ArrayList<>(numPiles);

    // Deal cards face down into piles
    for(int i = 0; i < numPiles; i++) {
      List<Card> pile = new ArrayList<>();
      for(int j = 0; j < i + 1; j++) {
        pile.add(deck.get(0));
        deck.remove(0);
      }
      tableauPiles.add(pile);
    }

    // Flip last card in each pile face up
    for(List<Card> pile : tableauPiles) {
      Card last = pile.get(pile.size() - 1);
      pile.set(pile.size()-1, new FaceDownCard());
      pile.add(last);
    }

    // Remaining cards to draw pile
    drawPile.addAll(deck);

    // Make top cards of draw pile face up
    for(int i = 0; i < numDraw; i++) {
      Card top = drawPile.get(0);
      drawPile.set(0, new FaceDownCard());
      drawPile.add(top);
    }

    gameStarted = true;
  }

  @Override
  public List<Card> getDeck() {
    return null;
  }

  @Override
  public void startGame(List<Card> deck, boolean shuffle, int numPiles, int numDraw) throws IllegalArgumentException, IllegalStateException {

  }

  public void movePile(int srcPile, int numCards, int destPile) {
    // Validate move
    if(!gameStarted) {
      throw new IllegalStateException("Game not started");
    }

    // Remove cards from src pile
    List<Card> movedCards = tableauPiles.get(srcPile).subList(0, numCards);
    tableauPiles.get(srcPile).removeAll(movedCards);

    // Add cards to dest pile
    tableauPiles.get(destPile).addAll(0, movedCards);

    // Flip top card of src pile if empty
    if(tableauPiles.get(srcPile).isEmpty()) {
      Card top = drawPile.remove(0);
      tableauPiles.get(srcPile).add(top);
    }
  }

  @Override
  public void moveDraw(int destPile) {

    // Validate game started
    if(!gameStarted) {
      throw new IllegalStateException("Game not started");
    }

    // Remove top draw card
    Card drawCard = drawPile.remove(0);

    // Add to destination pile
    tableauPiles.get(destPile).add(0, drawCard);

    // Flip next draw card
    Card newTop = drawPile.get(0);
    drawPile.set(0, new FaceDownCard());
    drawPile.add(0, newTop);
  }

  @Override
  public void moveToFoundation(int srcPile, int foundationPile) {

    // Validate game started
    if(!gameStarted) {
      throw new IllegalStateException("Game not started");
    }

    // Get card from source pile
    Card card = tableauPiles.get(srcPile).remove(tableauPiles.get(srcPile).size() - 1);

    // Add to foundation pile
    foundationPiles.get(foundationPile).add(card);

    // Flip top card of src pile if empty
    if(tableauPiles.get(srcPile).isEmpty()) {
      Card top = drawPile.remove(0);
      tableauPiles.get(srcPile).add(top);
    }
  }

  @Override
  public void moveDrawToFoundation(int foundationPile) {

    // Validate game started
    if(!gameStarted) {
      throw new IllegalStateException("Game not started");
    }

    // Get top draw card
    Card drawCard = drawPile.remove(0);

    // Add to foundation pile
    foundationPiles.get(foundationPile).add(drawCard);

    // Flip next draw card
    Card newTop = drawPile.get(0);
    drawPile.set(0, new FaceDownCard());
    drawPile.add(0, newTop);
  }

  @Override
  public void discardDraw() {

    // Validate game started
    if(!gameStarted) {
      throw new IllegalStateException("Game not started");
    }

    // Remove top draw card
    drawPile.remove(0);

    // Flip next draw card
    Card newTop = drawPile.get(0);
    drawPile.set(0, new FaceDownCard());
    drawPile.add(0, newTop);
  }




  public int getNumRows() {
    // Return number of tableau piles
    return tableauPiles.size();
  }

  @Override
  public int getNumPiles() {
    return tableauPiles.size();
  }

  @Override
  public int getNumDraw() {
    return drawPile.size();
  }

  @Override
  public boolean isGameOver() {
    // Game is over if all cards are in foundation piles
    return foundationPiles.stream()
            .mapToInt(List::size)
            .sum() == 52;
  }


  @Override
  public int getScore() {
    // Score is sum of foundation pile sizes
    return foundationPiles.stream()
            .mapToInt(List::size)
            .sum();
  }

  @Override
  public int getPileHeight(int pileNum) {
    return tableauPiles.get(pileNum).size();
  }

  @Override
  public boolean isCardVisible(int pileNum, int card) {
    // Card is visible if it's the last one in the pile
    int pileSize = tableauPiles.get(pileNum).size();
    return card == pileSize - 1;
  }

  @Override
  public Card getCardAt(int pileNum, int card) {
    return tableauPiles.get(pileNum).get(card);
  }

  @Override
  public Card getCardAt(int foundationPile) {
    List<Card> pile = foundationPiles.get(foundationPile);
    if (pile.isEmpty()) {
      return null;
    } else {
      return pile.get(pile.size() - 1);
    }
  }

  @Override
  public List<Card> getDrawCards() {
    return drawPile.subList(0, getNumDraw());
  }

  @Override
  public int getNumFoundations() {
    return foundationPiles.size();
  }
}
