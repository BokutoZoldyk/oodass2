package cs3500.klondike.view;


public interface TextView {

}
